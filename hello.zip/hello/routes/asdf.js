
/*
 * GET users listing.
 */

exports.ffff = function(req, res){
  res.send("asdf mothaf");
};